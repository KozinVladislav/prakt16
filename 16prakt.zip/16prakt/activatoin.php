<?php
include_once "connection.php";

if (isset($_POST['submit']))
{
	$log = $_POST['login'];
	$pas = $_POST['password'];

	$query = $connect->query(" SELECT `password` FROM `user` WHERE `login` = '$log'; ");
	$data = mysqli_fetch_assoc($query);
	
	if ($data['password'] === ($_POST['password']))
	{
		require_once('private_office.html');
	}	else die('<br>Неверный ввод логина или пароля');
}
