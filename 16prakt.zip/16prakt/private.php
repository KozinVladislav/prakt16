<?php
include_once "connection.php";
include_once "function.php";
#include_once "private_office.html";


$query = $connect->query(" SELECT * FROM `user` WHERE `login` = '$log';");
$res = $query->mysqli_fetch_assoc();
echo $res;
$row = $res;

if (isset($_POST['submit']))
{
	$log = $_POST['login'];
	$pas = $_POST['password'];
	
	if ($pas === ($_POST['repeatPassword']))
	{
		$connect->query("UPDATE `user` SET `name` = '$mas[1]', `surname` = '$mas[2]', `email` = '$mas[4]', `password` = '$mas[5]', `repeatPassword` = '$mas[6]', `sub1` = '$mas[7]', `sub2` = '$mas[8]', `sub3` = '$mas[9]' WHERE `login` = '$mas[3]'; ");
		echo "Изменения приняты";
	}
}

 
