<?php
include_once "../engine/connection.php";
include_once "../template/private_office.html";
include_once "../engine/function.php";

$query = $connect->query(" SELECT * FROM `user` WHERE `login` = '$log';");
$row = $query->fetch_assoc();
$mas = array();
$mas[1] = $row['name'];
$mas[2] = $row['surname'];
$mas[3] = $row['login'];
$mas[4] = $row['email'];
$mas[5] = $row['password'];
$mas[6] = $row['repeatPassword'];

$sub_checked = [

			'sub1' => ($row['sub1'] == '1') ? 'checked' : '',
			'sub2' => ($row['sub2'] == '1') ? 'checked' : '',
			'sub3' => ($row['sub3'] == '1') ? 'checked' : ''

		];

if (isset($_POST['submit1']))
{
	$connect->query(" UPDATE `user` SET  `name` = '$mas[1]', `surname` = '$mas[2]', `email` = '$mas[4]', 
		`password` = '$mas[5]', `repeatPassword` = '$mas[6]', `sub1` = '$mas[7]', 
		`sub2` = '$mas[8]', `sub3` = '$mas[9]' WHERE `login` = '$mas[3]'; ");
	echo "Изменения приняты";
}