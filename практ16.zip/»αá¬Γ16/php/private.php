<?php
include_once "../engine/connection.php";
include_once "../engine/function.php";

$login = $_POST['login'];
$query = $connect->query(" SELECT * FROM `user` WHERE `login` = '$login';");
$row = $query->fetch_assoc();

$mas = array();
$mas[1] = $row['name'];
$mas[2] = $row['surname'];
$mas[3] = $row['login'];
$mas[4] = $row['email'];
$mas[5] = $row['password'];
$mas[6] = $row['repeatPassword'];

$sub_checked = [

			'sub1' => ($row['sub1'] == '1') ? 'checked' : '',
			'sub2' => ($row['sub2'] == '1') ? 'checked' : '',
			'sub3' => ($row['sub3'] == '1') ? 'checked' : ''

		];

if (isset($_POST['subm']))
{
	if (count($_POST))
	{
		$sub = [

			'sub1' => 0,
			'sub2' => 0,
			'sub3' => 0

		];

		if (is_array($_POST['sub']))
			foreach ($_POST['sub'] as $s)
				$sub[$s] = 1;
		
		$pas = $_POST['password'];
		if ($pas === ($_POST['repeatPassword']))
		{
			$connect->query("UPDATE user SET name = '" . $_POST['name'] . "',
									surname 		= '" . $_POST['surname'] . "',
									email 			= '" . $_POST['email'] . "',
									password 		= '" . $_POST['password'] . "',
									repeatPassword 	= '" . $_POST['password'] . "',
									sub1 			= '" . $sub['sub1'] . "',
									sub2 			= '" . $sub['sub2'] . "',
									sub3 			= '" . $sub['sub3'] . "'	
									WHERE login = '" . $login . "' ");
			echo "Изменения приняты";
		} else die('поля Пароль и Повтор пароля не совпадают');
	}
}

$connect->close();