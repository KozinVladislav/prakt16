<?php 	
error_reporting(E_ERROR);
include_once "../engine/connection.php";
include_once "../engine/function.php";

#var_dump($_POST);
if (isset($_POST['submit'])) 
{
	include_once "../engine/array.php";
	if($mas[5] == $mas[6])
	{
		echo '<br>Вы зарегистрированы с данными:' .'<br>Имя: ' . $mas[1] . '<br>Фамилия: ' . $mas[2] . '<br>Логин: ' . $mas[3] . '<br>Почта: ' . $mas[4] . '<br>Пароль: ' . $mas[5]; 
		if (isset($_POST['sub'])) {
			echo '<br>Вы подписаны на: <br>';
			foreach ($_POST['sub'] as $key => $value)
			{
				echo  $value . '<br>';
			}
		}else die("<br>Подписок нет");

		$res = $connect->query("INSERT INTO `user` (`name`, `surname`, `login`, `email`, `password`, `repeatPassword`,`sub1`, `sub2`, `sub3` ) VALUES ('$mas[1]', '$mas[2]', '$mas[3]', '$mas[4]', '$mas[5]', '$mas[6]' , '$mas[7]', '$mas[8]', '$mas[9]');");	
	} else die ('Поля "Пароль" и "Повтор пароля" не совпадают');
}
