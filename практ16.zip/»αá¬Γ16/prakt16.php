<?php
header('Content-type: text/html; charset=utf-8');
	
$connect = new mysqli('localhost', 'root', '', 'prakt4');
if ($connect->connect_error) {
    die('Error : ('. $connect->connect_errno .') '. $connect->connect_error);
}
$connect->set_charset('utf8');
var_dump(mysqli_error($connect));

function test($value, $name, $pattern)
{
	if (!empty($_POST["$value"]))
	{	
		$var = $_POST["$value"];
		if (!preg_match($pattern, $var)) {
			die('Неккоректный ввод: ' . $name);
		}
	} else {
			die('Пустое поле: ' . $name);
		}
	
	return $var;
}
function testSub($sub)
{
	foreach ($_POST['sub'] as $key => $value) {
		if ($value === $sub) {
			return true;
		}
	}
	return false;
}

$mas = array();

if (isset($_POST['sub3']))
{
	$value = $_POST['login'];
	$query = $connect->query(" SELECT `password` FROM `user` WHERE `login` = '$value'; ");
	$data = mysqli_fetch_assoc($query);
	if ($data['password'] === ($_POST['password']))
	{
		require_once('private_office.html');
	}	else die('<br>Неверный ввод логина или пароля');
} else {
	$mas[1] = test('name', 'Имя', "/[A-Za-zА-Яа-яЁё0-9]{2,10}/u"); 
	$mas[2] = test('surname', 'Фамилия', "/[A-Za-zА-Яа-яЁё]{2,14}/u");
	$mas[3] = test('login', 'Логин', "/.{3,14}?/u");
	$mas[4] = test('email', 'email', "/[@]/u");
	$mas[5] = test('password', 'Пароль', "/(?=.*[A-Z]{1,})(?=.*\W{1}).{5,10}/u");
	$mas[6] = test('repeatPassword', 'Повтор пароля', "/(?=.*[A-Z]{1,})(?=.*\W{1}).{5,10}/u");
	$mas[7] = testSub('Новости');
	$mas[8] = testSub('Акции');
	$mas[9] = testSub('Мероприятия');	

	if (isset($_POST['sub1'])) 
	{
		if($mas[5] == $mas[6])
		{
			echo '<br>Вы зарегистрированы с данными:' .'<br>Имя: ' . $mas[1] . '<br>Фамилия: ' . $mas[2] . '<br>Логин: ' . $mas[3] . '<br>Почта: ' . $mas[4] . '<br>Пароль: ' . $mas[5] . '<br>Вы подписаны на: <br>';
			foreach ($_POST['sub'] as $key => $value) {
				echo  $value . '<br>';
			}

			$res = $connect->query("INSERT INTO `user` (`name`, `surname`, `login`, `email`, `password`, `repeatPassword`,`sub1`, `sub2`, `sub3` ) VALUES ('$mas[1]', '$mas[2]', '$mas[3]', '$mas[4]', '$mas[5]', '$mas[6]' , '$mas[7]', '$mas[8]', '$mas[9]');");	
		} 
	}

	if (isset($_POST['sub2']))
	{
		if ($_POST['password'] === ($_POST['repeatPassword']))
		{
			$connect->query("UPDATE `user` SET `name` = '$mas[1]', `surname` = '$mas[2]', `email` = '$mas[4]', `password` = '$mas[5]', `repeatPassword` = '$mas[6]', `sub1` = '$mas[7]', `sub2` = '$mas[8]', `sub3` = '$mas[9]' WHERE `login` = '$mas[3]'; ");
			echo "Изменения приняты";
		}
	} 
}

$connect->close();