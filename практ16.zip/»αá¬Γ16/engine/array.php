<?php
include_once "function.php";

$mas = array();
$mas[1] = test('name', 'Имя', "/[A-Za-zА-Яа-яЁё0-9]{2,10}/u"); 
$mas[2] = test('surname', 'Фамилия', "/[A-Za-zА-Яа-яЁё]{2,14}/u");	
$mas[3] = test('login', 'Логин', "/.{3,14}?/u");
$mas[4] = test('email', 'email', "/[@]/u");
$mas[5] = test('password', 'Пароль', "/(?=.*[A-Z]{1,})(?=.*\W{1}).{5,10}/u");
$mas[6] = test('repeatPassword', 'Повтор пароля', "/(?=.*[A-Z]{1,})(?=.*\W{1}).{5,10}/u");
$mas[7] = testSub('Новости');
$mas[8] = testSub('Акции');
$mas[9] = testSub('Мероприятия');	
